<?php

/* index.html.twig */
class __TwigTemplate_33527297fe132d65a7e9b6c98e7058f475e22df9cc79f91c27ed84f60e740f89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f40939070269974bf6fdf9499ad8c7a423051038e6e797f5455234496fc38a4 = $this->env->getExtension("native_profiler");
        $__internal_0f40939070269974bf6fdf9499ad8c7a423051038e6e797f5455234496fc38a4->enter($__internal_0f40939070269974bf6fdf9499ad8c7a423051038e6e797f5455234496fc38a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f40939070269974bf6fdf9499ad8c7a423051038e6e797f5455234496fc38a4->leave($__internal_0f40939070269974bf6fdf9499ad8c7a423051038e6e797f5455234496fc38a4_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_b633b20dcaaa358676af7c6005cf331b5d157be89682653c253e6f39e813ef5a = $this->env->getExtension("native_profiler");
        $__internal_b633b20dcaaa358676af7c6005cf331b5d157be89682653c253e6f39e813ef5a->enter($__internal_b633b20dcaaa358676af7c6005cf331b5d157be89682653c253e6f39e813ef5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    Welcome to your new Silex Application!
";
        
        $__internal_b633b20dcaaa358676af7c6005cf331b5d157be89682653c253e6f39e813ef5a->leave($__internal_b633b20dcaaa358676af7c6005cf331b5d157be89682653c253e6f39e813ef5a_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "layout.html.twig" %}*/
/* */
/* {% block content %}*/
/*     Welcome to your new Silex Application!*/
/* {% endblock %}*/
/* */
