<?php

/* layout.html.twig */
class __TwigTemplate_b9e19b140108212c8932124a90c472cad1893ad97ddfebaf2f69f96634f6b3f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93e0f7a82755e1730011a7c8c444dc1e71b7aa3bfef4964c266102d5c09bdb5b = $this->env->getExtension("native_profiler");
        $__internal_93e0f7a82755e1730011a7c8c444dc1e71b7aa3bfef4964c266102d5c09bdb5b->enter($__internal_93e0f7a82755e1730011a7c8c444dc1e71b7aa3bfef4964c266102d5c09bdb5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo " - Leandro Beron</title>
        <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />
    </head>
    <body>
        <div class=\"container\">
            <h1>Tesis</h1>
            <hr>
            ";
        // line 12
        $this->displayBlock('content', $context, $blocks);
        // line 13
        echo "        </div>
        <script src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>
        <script>
            // 2. This code loads the IFrame Player API code asynchronously.
            var tag = document.createElement('script');

            tag.src = \"https://www.youtube.com/iframe_api\";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        </script>
        ";
        // line 25
        $this->displayBlock('javascript', $context, $blocks);
        // line 26
        echo "    </body>
</html>
";
        
        $__internal_93e0f7a82755e1730011a7c8c444dc1e71b7aa3bfef4964c266102d5c09bdb5b->leave($__internal_93e0f7a82755e1730011a7c8c444dc1e71b7aa3bfef4964c266102d5c09bdb5b_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_c8a5b66becfa33dce703f2e211081ecf690d63689622ce78443527fc78dd58c4 = $this->env->getExtension("native_profiler");
        $__internal_c8a5b66becfa33dce703f2e211081ecf690d63689622ce78443527fc78dd58c4->enter($__internal_c8a5b66becfa33dce703f2e211081ecf690d63689622ce78443527fc78dd58c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "";
        
        $__internal_c8a5b66becfa33dce703f2e211081ecf690d63689622ce78443527fc78dd58c4->leave($__internal_c8a5b66becfa33dce703f2e211081ecf690d63689622ce78443527fc78dd58c4_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_c96b3485e655b0a73e1f1e341e545d30e00e7cf63ccb39f5df0d8373db859c8c = $this->env->getExtension("native_profiler");
        $__internal_c96b3485e655b0a73e1f1e341e545d30e00e7cf63ccb39f5df0d8373db859c8c->enter($__internal_c96b3485e655b0a73e1f1e341e545d30e00e7cf63ccb39f5df0d8373db859c8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_c96b3485e655b0a73e1f1e341e545d30e00e7cf63ccb39f5df0d8373db859c8c->leave($__internal_c96b3485e655b0a73e1f1e341e545d30e00e7cf63ccb39f5df0d8373db859c8c_prof);

    }

    // line 25
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_650e0c8c84dec6b3d9d82e36011e3f3622f4916b73c6f7836c6858ff8edb0fdc = $this->env->getExtension("native_profiler");
        $__internal_650e0c8c84dec6b3d9d82e36011e3f3622f4916b73c6f7836c6858ff8edb0fdc->enter($__internal_650e0c8c84dec6b3d9d82e36011e3f3622f4916b73c6f7836c6858ff8edb0fdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        
        $__internal_650e0c8c84dec6b3d9d82e36011e3f3622f4916b73c6f7836c6858ff8edb0fdc->leave($__internal_650e0c8c84dec6b3d9d82e36011e3f3622f4916b73c6f7836c6858ff8edb0fdc_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 25,  95 => 12,  83 => 4,  74 => 26,  72 => 25,  60 => 16,  56 => 15,  52 => 14,  49 => 13,  47 => 12,  38 => 6,  34 => 5,  30 => 4,  25 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <title>{% block title '' %} - Leandro Beron</title>*/
/*         <link rel="stylesheet" href="{{ asset('bower_components/bootstrap/dist/css/bootstrap.min.css') }}">*/
/*         <link href="{{ asset('css/main.css') }}" rel="stylesheet" type="text/css" />*/
/*     </head>*/
/*     <body>*/
/*         <div class="container">*/
/*             <h1>Tesis</h1>*/
/*             <hr>*/
/*             {% block content %}{% endblock %}*/
/*         </div>*/
/*         <script src="{{ asset('bower_components/jquery/dist/jquery.min.js') }}"></script>*/
/*         <script src="{{ asset('bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>*/
/*         <script src="{{ asset('js/script.js') }}"></script>*/
/*         <script>*/
/*             // 2. This code loads the IFrame Player API code asynchronously.*/
/*             var tag = document.createElement('script');*/
/* */
/*             tag.src = "https://www.youtube.com/iframe_api";*/
/*             var firstScriptTag = document.getElementsByTagName('script')[0];*/
/*             firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);*/
/*         </script>*/
/*         {% block javascript %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
