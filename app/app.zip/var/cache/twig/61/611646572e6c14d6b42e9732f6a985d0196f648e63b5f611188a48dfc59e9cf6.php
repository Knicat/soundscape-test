<?php

/* videos/1.html.twig */
class __TwigTemplate_f51c82ca481078e6fd476a5ae26728b38eeea0f8c5ec5b78a251201db453c05f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "videos/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b83609fad4d75be7c9d30368718c8f63bb953a5ed039b540115a3d6dc0c4bb0 = $this->env->getExtension("native_profiler");
        $__internal_3b83609fad4d75be7c9d30368718c8f63bb953a5ed039b540115a3d6dc0c4bb0->enter($__internal_3b83609fad4d75be7c9d30368718c8f63bb953a5ed039b540115a3d6dc0c4bb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "videos/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3b83609fad4d75be7c9d30368718c8f63bb953a5ed039b540115a3d6dc0c4bb0->leave($__internal_3b83609fad4d75be7c9d30368718c8f63bb953a5ed039b540115a3d6dc0c4bb0_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_ababfb9bca41be448ea4666dad9de2ccec7ae49779a4af6bf59c194a9807d831 = $this->env->getExtension("native_profiler");
        $__internal_ababfb9bca41be448ea4666dad9de2ccec7ae49779a4af6bf59c194a9807d831->enter($__internal_ababfb9bca41be448ea4666dad9de2ccec7ae49779a4af6bf59c194a9807d831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto 3</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

    <p class=\"text-center\">

        <a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Anterior</a>

    </p>
";
        
        $__internal_ababfb9bca41be448ea4666dad9de2ccec7ae49779a4af6bf59c194a9807d831->leave($__internal_ababfb9bca41be448ea4666dad9de2ccec7ae49779a4af6bf59c194a9807d831_prof);

    }

    // line 16
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_c327e0bd8d52b2e6085efcaa706bc092648732aa0eb31403dabc4f5e07bb1979 = $this->env->getExtension("native_profiler");
        $__internal_c327e0bd8d52b2e6085efcaa706bc092648732aa0eb31403dabc4f5e07bb1979->enter($__internal_c327e0bd8d52b2e6085efcaa706bc092648732aa0eb31403dabc4f5e07bb1979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 17
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '500px',
                width: '100%',
                videoId: 'ZLls1Wn6070',
                playerVars: { controls: 0},
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(";
        // line 40
        echo twig_escape_filter($this->env, (isset($context["volumen"]) ? $context["volumen"] : $this->getContext($context, "volumen")), "html", null, true);
        echo ");
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;

        function onPlayerStateChange(event) {
            if(event.data === 0) {
                window.location.href = '";
        // line 50
        echo $this->env->getExtension('routing')->getPath("form_1");
        echo "?";
        echo (isset($context["qs"]) ? $context["qs"] : $this->getContext($context, "qs"));
        echo "';
            }
        }

        function stopVideo() {
            player.stopVideo();
        }



        \$(\".volver-a-empezar\").click(function(e){
            e.preventDefault();
            player.playVideoAt(0);
        });

    </script>

";
        
        $__internal_c327e0bd8d52b2e6085efcaa706bc092648732aa0eb31403dabc4f5e07bb1979->leave($__internal_c327e0bd8d52b2e6085efcaa706bc092648732aa0eb31403dabc4f5e07bb1979_prof);

    }

    public function getTemplateName()
    {
        return "videos/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 50,  95 => 40,  70 => 17,  64 => 16,  53 => 12,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto 3</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/*     <p class="text-center">*/
/* */
/*         <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Anterior</a>*/
/* */
/*     </p>*/
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '500px',*/
/*                 width: '100%',*/
/*                 videoId: 'ZLls1Wn6070',*/
/*                 playerVars: { controls: 0},*/
/*                 events: {*/
/*                     'onReady': onPlayerReady,*/
/*                     'onStateChange': onPlayerStateChange*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume({{ volumen }});*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/* */
/*         function onPlayerStateChange(event) {*/
/*             if(event.data === 0) {*/
/*                 window.location.href = '{{ path('form_1') }}?{{ qs|raw }}';*/
/*             }*/
/*         }*/
/* */
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/* */
/* */
/*         $(".volver-a-empezar").click(function(e){*/
/*             e.preventDefault();*/
/*             player.playVideoAt(0);*/
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
