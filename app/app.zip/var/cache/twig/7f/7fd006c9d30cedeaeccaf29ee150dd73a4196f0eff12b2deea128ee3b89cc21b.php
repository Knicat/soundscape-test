<?php

/* layout.html.twig */
class __TwigTemplate_d87a01f84442b6c42fbf9c479e646a87c43b450ff644f9ba38cd6cbe82a68040 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad6b5470023b3fc965adda4fe27c19d1e92e19c39150dbea6f2991f6c98922b0 = $this->env->getExtension("native_profiler");
        $__internal_ad6b5470023b3fc965adda4fe27c19d1e92e19c39150dbea6f2991f6c98922b0->enter($__internal_ad6b5470023b3fc965adda4fe27c19d1e92e19c39150dbea6f2991f6c98922b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo " - Leandro Beron</title>
        <link href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />
    </head>
    <body>
        ";
        // line 8
        $this->displayBlock('content', $context, $blocks);
        // line 9
        echo "    </body>
</html>
";
        
        $__internal_ad6b5470023b3fc965adda4fe27c19d1e92e19c39150dbea6f2991f6c98922b0->leave($__internal_ad6b5470023b3fc965adda4fe27c19d1e92e19c39150dbea6f2991f6c98922b0_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_b83a5e4ac9d5d08a15d97b3fe3f4238664d96a90836f773be6d398f5e6ef6705 = $this->env->getExtension("native_profiler");
        $__internal_b83a5e4ac9d5d08a15d97b3fe3f4238664d96a90836f773be6d398f5e6ef6705->enter($__internal_b83a5e4ac9d5d08a15d97b3fe3f4238664d96a90836f773be6d398f5e6ef6705_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "";
        
        $__internal_b83a5e4ac9d5d08a15d97b3fe3f4238664d96a90836f773be6d398f5e6ef6705->leave($__internal_b83a5e4ac9d5d08a15d97b3fe3f4238664d96a90836f773be6d398f5e6ef6705_prof);

    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        $__internal_3c9219b12b5ac4d30f870a5a3c10f10f4525bb9145eb6a94ceecc58e7b27d5b4 = $this->env->getExtension("native_profiler");
        $__internal_3c9219b12b5ac4d30f870a5a3c10f10f4525bb9145eb6a94ceecc58e7b27d5b4->enter($__internal_3c9219b12b5ac4d30f870a5a3c10f10f4525bb9145eb6a94ceecc58e7b27d5b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_3c9219b12b5ac4d30f870a5a3c10f10f4525bb9145eb6a94ceecc58e7b27d5b4->leave($__internal_3c9219b12b5ac4d30f870a5a3c10f10f4525bb9145eb6a94ceecc58e7b27d5b4_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 8,  50 => 4,  41 => 9,  39 => 8,  33 => 5,  29 => 4,  24 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <title>{% block title '' %} - Leandro Beron</title>*/
/*         <link href="{{ asset('css/main.css') }}" rel="stylesheet" type="text/css" />*/
/*     </head>*/
/*     <body>*/
/*         {% block content %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
