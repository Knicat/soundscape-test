<?php

/* index.html.twig */
class __TwigTemplate_46507ed0aa63b595d9dab1073cee246dc3754be4b3d88cd9266f552d69300f8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8002a645471d039053796e9852c8175cf225f190df7ddf51e11c30cc880cb6c4 = $this->env->getExtension("native_profiler");
        $__internal_8002a645471d039053796e9852c8175cf225f190df7ddf51e11c30cc880cb6c4->enter($__internal_8002a645471d039053796e9852c8175cf225f190df7ddf51e11c30cc880cb6c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8002a645471d039053796e9852c8175cf225f190df7ddf51e11c30cc880cb6c4->leave($__internal_8002a645471d039053796e9852c8175cf225f190df7ddf51e11c30cc880cb6c4_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_7ff31b73b4f15184200975c4416bbea8e6b5208adf1ea18c7cef29d1e68b4f17 = $this->env->getExtension("native_profiler");
        $__internal_7ff31b73b4f15184200975c4416bbea8e6b5208adf1ea18c7cef29d1e68b4f17->enter($__internal_7ff31b73b4f15184200975c4416bbea8e6b5208adf1ea18c7cef29d1e68b4f17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <p class=\"text-center\"><a href=\"";
        echo $this->env->getExtension('routing')->getPath("calibracion_1");
        echo "\" class=\"btn btn-primary\">Empezar</a></p>
";
        
        $__internal_7ff31b73b4f15184200975c4416bbea8e6b5208adf1ea18c7cef29d1e68b4f17->leave($__internal_7ff31b73b4f15184200975c4416bbea8e6b5208adf1ea18c7cef29d1e68b4f17_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "layout.html.twig" %}*/
/* */
/* {% block content %}*/
/*     <p class="text-center"><a href="{{ path('calibracion_1') }}" class="btn btn-primary">Empezar</a></p>*/
/* {% endblock %}*/
/* */
