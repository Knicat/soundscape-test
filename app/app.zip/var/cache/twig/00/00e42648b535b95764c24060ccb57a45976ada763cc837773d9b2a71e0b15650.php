<?php

/* form/1.html.twig */
class __TwigTemplate_357408322e34b46bd2b8912bc046fec4b26fe2a6b2d8c2dcb1bac42efc8dccd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "form/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90a6fd227a08c7cc3fa4b36b20987094550f71017f76cd20371f6b5b239fbcc7 = $this->env->getExtension("native_profiler");
        $__internal_90a6fd227a08c7cc3fa4b36b20987094550f71017f76cd20371f6b5b239fbcc7->enter($__internal_90a6fd227a08c7cc3fa4b36b20987094550f71017f76cd20371f6b5b239fbcc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_90a6fd227a08c7cc3fa4b36b20987094550f71017f76cd20371f6b5b239fbcc7->leave($__internal_90a6fd227a08c7cc3fa4b36b20987094550f71017f76cd20371f6b5b239fbcc7_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_5a47375c0c23b7a65ea8a05a12d1fcb9932fae6058818e12a53529edeb22fffc = $this->env->getExtension("native_profiler");
        $__internal_5a47375c0c23b7a65ea8a05a12d1fcb9932fae6058818e12a53529edeb22fffc->enter($__internal_5a47375c0c23b7a65ea8a05a12d1fcb9932fae6058818e12a53529edeb22fffc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <h1>Formulario 1</h1>
    <hr>
    ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_sonoro", array()), 'label');
        echo "
                ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_sonoro", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Desagradable</td>
                        <td>";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_sonoro", array()), 'widget');
        echo "</td>
                        <td>Agradable</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "animacion", array()), 'label');
        echo "
                ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "animacion", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Sin vida</td>
                        <td>";
        // line 33
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "animacion", array()), 'widget');
        echo "</td>
                        <td>Animado</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 43
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_global", array()), 'label');
        echo "
                ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_global", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Débil</td>
                        <td>";
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_global", array()), 'widget');
        echo "</td>
                        <td>Fuerte</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <hr>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 61
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_las_motocicletas", array()), 'label');
        echo "
                ";
        // line 62
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_las_motocicletas", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Débil</td>
                        <td>";
        // line 68
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_las_motocicletas", array()), 'widget');
        echo "</td>
                        <td>Fuerte</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 78
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_livianos", array()), 'label');
        echo "
                ";
        // line 79
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_livianos", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Débil</td>
                        <td>";
        // line 85
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_livianos", array()), 'widget');
        echo "</td>
                        <td>Fuerte</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 95
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_pesados", array()), 'label');
        echo "
                ";
        // line 96
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_pesados", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Débil</td>
                        <td>";
        // line 102
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "intensidad_sonora_de_los_vehiculos_pesados", array()), 'widget');
        echo "</td>
                        <td>Fuerte</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <hr>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 113
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_vehiculos", array()), 'label');
        echo "
                ";
        // line 114
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_vehiculos", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Muy poco presente</td>
                        <td>";
        // line 120
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_vehiculos", array()), 'widget');
        echo "</td>
                        <td>Siempre presente</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 130
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_las_voces", array()), 'label');
        echo "
                ";
        // line 131
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_las_voces", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Muy poco presente</td>
                        <td>";
        // line 137
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_las_voces", array()), 'widget');
        echo "</td>
                        <td>Siempre presente</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 147
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pasos", array()), 'label');
        echo "
                ";
        // line 148
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pasos", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Muy poco presente</td>
                        <td>";
        // line 154
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pasos", array()), 'widget');
        echo "</td>
                        <td>Siempre presente</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 164
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pajaros", array()), 'label');
        echo "
                ";
        // line 165
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pajaros", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Muy poco presente</td>
                        <td>";
        // line 171
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tiempo_de_presencia_de_los_pajaros", array()), 'widget');
        echo "</td>
                        <td>Siempre presente</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <hr>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 182
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_visual", array()), 'label');
        echo "
                ";
        // line 183
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_visual", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Desagradable</td>
                        <td>";
        // line 189
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "agrado_visual", array()), 'widget');
        echo "</td>
                        <td>Agradable</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class=\"formulario_row\">
        <tr>
            <td>
                ";
        // line 199
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "familiaridad_del_sonido", array()), 'label');
        echo "
                ";
        // line 200
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "familiaridad_del_sonido", array()), 'errors');
        echo "
            </td>
            <td>
                <table class=\"formulario_row\">
                    <tr>
                        <td>Sorprendente</td>
                        <td>";
        // line 206
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "familiaridad_del_sonido", array()), 'widget');
        echo "</td>
                        <td>Familiar</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    ";
        // line 213
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
    ";
        // line 214
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_5a47375c0c23b7a65ea8a05a12d1fcb9932fae6058818e12a53529edeb22fffc->leave($__internal_5a47375c0c23b7a65ea8a05a12d1fcb9932fae6058818e12a53529edeb22fffc_prof);

    }

    public function getTemplateName()
    {
        return "form/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  367 => 214,  363 => 213,  353 => 206,  344 => 200,  340 => 199,  327 => 189,  318 => 183,  314 => 182,  300 => 171,  291 => 165,  287 => 164,  274 => 154,  265 => 148,  261 => 147,  248 => 137,  239 => 131,  235 => 130,  222 => 120,  213 => 114,  209 => 113,  195 => 102,  186 => 96,  182 => 95,  169 => 85,  160 => 79,  156 => 78,  143 => 68,  134 => 62,  130 => 61,  116 => 50,  107 => 44,  103 => 43,  90 => 33,  81 => 27,  77 => 26,  64 => 16,  55 => 10,  51 => 9,  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <h1>Formulario 1</h1>*/
/*     <hr>*/
/*     {{ form_start(form, {'attr':{'novalidate':'novalidate'}}) }}*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.agrado_sonoro) }}*/
/*                 {{ form_errors(form.agrado_sonoro) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Desagradable</td>*/
/*                         <td>{{ form_widget(form.agrado_sonoro) }}</td>*/
/*                         <td>Agradable</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.animacion) }}*/
/*                 {{ form_errors(form.animacion) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Sin vida</td>*/
/*                         <td>{{ form_widget(form.animacion) }}</td>*/
/*                         <td>Animado</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.intensidad_sonora_global) }}*/
/*                 {{ form_errors(form.intensidad_sonora_global) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Débil</td>*/
/*                         <td>{{ form_widget(form.intensidad_sonora_global) }}</td>*/
/*                         <td>Fuerte</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <hr>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.intensidad_sonora_de_las_motocicletas) }}*/
/*                 {{ form_errors(form.intensidad_sonora_de_las_motocicletas) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Débil</td>*/
/*                         <td>{{ form_widget(form.intensidad_sonora_de_las_motocicletas) }}</td>*/
/*                         <td>Fuerte</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.intensidad_sonora_de_los_vehiculos_livianos) }}*/
/*                 {{ form_errors(form.intensidad_sonora_de_los_vehiculos_livianos) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Débil</td>*/
/*                         <td>{{ form_widget(form.intensidad_sonora_de_los_vehiculos_livianos) }}</td>*/
/*                         <td>Fuerte</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.intensidad_sonora_de_los_vehiculos_pesados) }}*/
/*                 {{ form_errors(form.intensidad_sonora_de_los_vehiculos_pesados) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Débil</td>*/
/*                         <td>{{ form_widget(form.intensidad_sonora_de_los_vehiculos_pesados) }}</td>*/
/*                         <td>Fuerte</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <hr>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.tiempo_de_presencia_de_los_vehiculos) }}*/
/*                 {{ form_errors(form.tiempo_de_presencia_de_los_vehiculos) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Muy poco presente</td>*/
/*                         <td>{{ form_widget(form.tiempo_de_presencia_de_los_vehiculos) }}</td>*/
/*                         <td>Siempre presente</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.tiempo_de_presencia_de_las_voces) }}*/
/*                 {{ form_errors(form.tiempo_de_presencia_de_las_voces) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Muy poco presente</td>*/
/*                         <td>{{ form_widget(form.tiempo_de_presencia_de_las_voces) }}</td>*/
/*                         <td>Siempre presente</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.tiempo_de_presencia_de_los_pasos) }}*/
/*                 {{ form_errors(form.tiempo_de_presencia_de_los_pasos) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Muy poco presente</td>*/
/*                         <td>{{ form_widget(form.tiempo_de_presencia_de_los_pasos) }}</td>*/
/*                         <td>Siempre presente</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.tiempo_de_presencia_de_los_pajaros) }}*/
/*                 {{ form_errors(form.tiempo_de_presencia_de_los_pajaros) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Muy poco presente</td>*/
/*                         <td>{{ form_widget(form.tiempo_de_presencia_de_los_pajaros) }}</td>*/
/*                         <td>Siempre presente</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <hr>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.agrado_visual) }}*/
/*                 {{ form_errors(form.agrado_visual) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Desagradable</td>*/
/*                         <td>{{ form_widget(form.agrado_visual) }}</td>*/
/*                         <td>Agradable</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     <table class="formulario_row">*/
/*         <tr>*/
/*             <td>*/
/*                 {{ form_label(form.familiaridad_del_sonido) }}*/
/*                 {{ form_errors(form.familiaridad_del_sonido) }}*/
/*             </td>*/
/*             <td>*/
/*                 <table class="formulario_row">*/
/*                     <tr>*/
/*                         <td>Sorprendente</td>*/
/*                         <td>{{ form_widget(form.familiaridad_del_sonido) }}</td>*/
/*                         <td>Familiar</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </td>*/
/*         </tr>*/
/*     </table>*/
/*     {{ form_row(form.submit) }}*/
/*     {{ form_end(form) }}*/
/* {% endblock %}*/
