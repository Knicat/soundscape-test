<?php

/* videos/1.html.twig */
class __TwigTemplate_644dd3371d8a196929ee3576b1e808550936d176c57f8989b00e6aac260ec2e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "videos/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f347b8eba3f498005bff659720d11ac1c9b4690fc75bdc7faae58be6971c5fec = $this->env->getExtension("native_profiler");
        $__internal_f347b8eba3f498005bff659720d11ac1c9b4690fc75bdc7faae58be6971c5fec->enter($__internal_f347b8eba3f498005bff659720d11ac1c9b4690fc75bdc7faae58be6971c5fec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "videos/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f347b8eba3f498005bff659720d11ac1c9b4690fc75bdc7faae58be6971c5fec->leave($__internal_f347b8eba3f498005bff659720d11ac1c9b4690fc75bdc7faae58be6971c5fec_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_bdec131b76a4e8c2f2e223444522685a7b6acb861bc4e0bd200acfa56ac7e827 = $this->env->getExtension("native_profiler");
        $__internal_bdec131b76a4e8c2f2e223444522685a7b6acb861bc4e0bd200acfa56ac7e827->enter($__internal_bdec131b76a4e8c2f2e223444522685a7b6acb861bc4e0bd200acfa56ac7e827_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto 3</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

    <p class=\"text-center\">




        <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Anterior</a>

        <a href=\"#\" class=\"btn btn-default volver-a-empezar\">Volver a empezar</a>

        <a href=\"\" disabled=\"disabled\" class=\"btn btn-primary siguiente\">Siguiente</a>
    </p>
";
        
        $__internal_bdec131b76a4e8c2f2e223444522685a7b6acb861bc4e0bd200acfa56ac7e827->leave($__internal_bdec131b76a4e8c2f2e223444522685a7b6acb861bc4e0bd200acfa56ac7e827_prof);

    }

    // line 22
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_a3cc23d85256952e3676abdbcf054f07ff0f32cb16e47af7feaada9053a5d34f = $this->env->getExtension("native_profiler");
        $__internal_a3cc23d85256952e3676abdbcf054f07ff0f32cb16e47af7feaada9053a5d34f->enter($__internal_a3cc23d85256952e3676abdbcf054f07ff0f32cb16e47af7feaada9053a5d34f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 23
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '500px',
                width: '100%',
                videoId: 'ZLls1Wn6070',
                playerVars: { controls: 0},
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(";
        // line 46
        echo twig_escape_filter($this->env, (isset($context["volumen"]) ? $context["volumen"] : $this->getContext($context, "volumen")), "html", null, true);
        echo ");
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;

        function onPlayerStateChange(event) {
            if(event.data === 0) {
                window.location.href = '";
        // line 56
        echo $this->env->getExtension('routing')->getPath("form_1");
        echo "';
            }
        }

        function stopVideo() {
            player.stopVideo();
        }



        \$(\".volver-a-empezar\").click(function(e){
            e.preventDefault();
            player.playVideoAt(0);
        });

    </script>

";
        
        $__internal_a3cc23d85256952e3676abdbcf054f07ff0f32cb16e47af7feaada9053a5d34f->leave($__internal_a3cc23d85256952e3676abdbcf054f07ff0f32cb16e47af7feaada9053a5d34f_prof);

    }

    public function getTemplateName()
    {
        return "videos/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 56,  101 => 46,  76 => 23,  70 => 22,  56 => 15,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto 3</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/*     <p class="text-center">*/
/* */
/* */
/* */
/* */
/*         <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Anterior</a>*/
/* */
/*         <a href="#" class="btn btn-default volver-a-empezar">Volver a empezar</a>*/
/* */
/*         <a href="" disabled="disabled" class="btn btn-primary siguiente">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '500px',*/
/*                 width: '100%',*/
/*                 videoId: 'ZLls1Wn6070',*/
/*                 playerVars: { controls: 0},*/
/*                 events: {*/
/*                     'onReady': onPlayerReady,*/
/*                     'onStateChange': onPlayerStateChange*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume({{ volumen }});*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/* */
/*         function onPlayerStateChange(event) {*/
/*             if(event.data === 0) {*/
/*                 window.location.href = '{{ path('form_1') }}';*/
/*             }*/
/*         }*/
/* */
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/* */
/* */
/*         $(".volver-a-empezar").click(function(e){*/
/*             e.preventDefault();*/
/*             player.playVideoAt(0);*/
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
