<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_84f360f5dacf20b17a5ab714682ff224cef1729d22262ad72669e60f7cb6786c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e18624cbb5d5ef95d961ee2eeffc9d944f37468fcf83dc19748df5e8b4afc072 = $this->env->getExtension("native_profiler");
        $__internal_e18624cbb5d5ef95d961ee2eeffc9d944f37468fcf83dc19748df5e8b4afc072->enter($__internal_e18624cbb5d5ef95d961ee2eeffc9d944f37468fcf83dc19748df5e8b4afc072_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e18624cbb5d5ef95d961ee2eeffc9d944f37468fcf83dc19748df5e8b4afc072->leave($__internal_e18624cbb5d5ef95d961ee2eeffc9d944f37468fcf83dc19748df5e8b4afc072_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c84de3a321153ff89b61b0d27a6ef5d57cb3084a537b34730b1a268573e56aef = $this->env->getExtension("native_profiler");
        $__internal_c84de3a321153ff89b61b0d27a6ef5d57cb3084a537b34730b1a268573e56aef->enter($__internal_c84de3a321153ff89b61b0d27a6ef5d57cb3084a537b34730b1a268573e56aef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c84de3a321153ff89b61b0d27a6ef5d57cb3084a537b34730b1a268573e56aef->leave($__internal_c84de3a321153ff89b61b0d27a6ef5d57cb3084a537b34730b1a268573e56aef_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_f511dc192cdd00cd5339296cb82b73db8da13745366c8a73d7d14ff5abd24dfc = $this->env->getExtension("native_profiler");
        $__internal_f511dc192cdd00cd5339296cb82b73db8da13745366c8a73d7d14ff5abd24dfc->enter($__internal_f511dc192cdd00cd5339296cb82b73db8da13745366c8a73d7d14ff5abd24dfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_f511dc192cdd00cd5339296cb82b73db8da13745366c8a73d7d14ff5abd24dfc->leave($__internal_f511dc192cdd00cd5339296cb82b73db8da13745366c8a73d7d14ff5abd24dfc_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_aab1d21558a950b1ca87b90b4a0f95563b58c4f3472e317106b8b97282f9c1b1 = $this->env->getExtension("native_profiler");
        $__internal_aab1d21558a950b1ca87b90b4a0f95563b58c4f3472e317106b8b97282f9c1b1->enter($__internal_aab1d21558a950b1ca87b90b4a0f95563b58c4f3472e317106b8b97282f9c1b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_aab1d21558a950b1ca87b90b4a0f95563b58c4f3472e317106b8b97282f9c1b1->leave($__internal_aab1d21558a950b1ca87b90b4a0f95563b58c4f3472e317106b8b97282f9c1b1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
