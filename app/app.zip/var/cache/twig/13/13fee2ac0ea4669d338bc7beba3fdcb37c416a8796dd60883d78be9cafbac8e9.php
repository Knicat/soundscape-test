<?php

/* calibracion/1.html.twig */
class __TwigTemplate_ebe11d730d7a2b9956fc1b01b745b0cad5432724faabdb72222df26e72056d30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "calibracion/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9d3d6446d87ae9daab474a35c64164dd5ae5413513b0bca4cf1fa42225f7048 = $this->env->getExtension("native_profiler");
        $__internal_c9d3d6446d87ae9daab474a35c64164dd5ae5413513b0bca4cf1fa42225f7048->enter($__internal_c9d3d6446d87ae9daab474a35c64164dd5ae5413513b0bca4cf1fa42225f7048_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calibracion/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9d3d6446d87ae9daab474a35c64164dd5ae5413513b0bca4cf1fa42225f7048->leave($__internal_c9d3d6446d87ae9daab474a35c64164dd5ae5413513b0bca4cf1fa42225f7048_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_2f9778e1c576debbe6961edfc97c6dd2e8757aaae32e006dc986b32a87465b6c = $this->env->getExtension("native_profiler");
        $__internal_2f9778e1c576debbe6961edfc97c6dd2e8757aaae32e006dc986b32a87465b6c->enter($__internal_2f9778e1c576debbe6961edfc97c6dd2e8757aaae32e006dc986b32a87465b6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p class=\"text-center\">
        <a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\" class=\"btn btn-primary\">Anterior</a>
        <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Siguiente</a>
    </p>
";
        
        $__internal_2f9778e1c576debbe6961edfc97c6dd2e8757aaae32e006dc986b32a87465b6c->leave($__internal_2f9778e1c576debbe6961edfc97c6dd2e8757aaae32e006dc986b32a87465b6c_prof);

    }

    public function getTemplateName()
    {
        return "calibracion/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 6,  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p class="text-center">*/
/*         <a href="{{ path('homepage') }}" class="btn btn-primary">Anterior</a>*/
/*         <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
