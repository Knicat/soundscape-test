<?php

/* calibracion/2.html.twig */
class __TwigTemplate_4856bc429706e9867790e9112bc28af421e35d36859f217a6c2338286118bb15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "calibracion/2.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd184bce21f09e5dd117fadbe261a70d83462e60601f732998e9b968e7fc4941 = $this->env->getExtension("native_profiler");
        $__internal_fd184bce21f09e5dd117fadbe261a70d83462e60601f732998e9b968e7fc4941->enter($__internal_fd184bce21f09e5dd117fadbe261a70d83462e60601f732998e9b968e7fc4941_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calibracion/2.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fd184bce21f09e5dd117fadbe261a70d83462e60601f732998e9b968e7fc4941->leave($__internal_fd184bce21f09e5dd117fadbe261a70d83462e60601f732998e9b968e7fc4941_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_07adf2450420c5b6806733081e2ad2fa4b06ef41519b1b63fc93a4c9474cb7d3 = $this->env->getExtension("native_profiler");
        $__internal_07adf2450420c5b6806733081e2ad2fa4b06ef41519b1b63fc93a4c9474cb7d3->enter($__internal_07adf2450420c5b6806733081e2ad2fa4b06ef41519b1b63fc93a4c9474cb7d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

    <p class=\"text-center\">




    <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("calibracion_1");
        echo "\" class=\"btn btn-primary\">Anterior</a>
        <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("calibracion_3");
        echo "\" class=\"btn btn-primary siguiente\">Siguiente</a>
    </p>
";
        
        $__internal_07adf2450420c5b6806733081e2ad2fa4b06ef41519b1b63fc93a4c9474cb7d3->leave($__internal_07adf2450420c5b6806733081e2ad2fa4b06ef41519b1b63fc93a4c9474cb7d3_prof);

    }

    // line 19
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_0fd3beb5143128660cef4706d28b2db037f90457f048d57e72764fbd0cc7acd4 = $this->env->getExtension("native_profiler");
        $__internal_0fd3beb5143128660cef4706d28b2db037f90457f048d57e72764fbd0cc7acd4->enter($__internal_0fd3beb5143128660cef4706d28b2db037f90457f048d57e72764fbd0cc7acd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 20
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '390',
                width: '640',
                videoId: 'M7lc1UVf-VE',
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(0);
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;
        function onPlayerStateChange(event) {
            console.log(event);
            /*if (event.data == YT.PlayerState.PLAYING && !done) {
                setTimeout(stopVideo, 6000);
                done = true;
            }*/
        }
        function stopVideo() {
            player.stopVideo();
        }

        \$btnSiguiente.click(function(e){
            e.preventDefault();
            if (player.getVolume() == 0) {
                alert(\"Por favor ajuste el volumen\");
                return false;
            }

            window.location.href = \$(this).attr('href') + \"?vol=\" + player.getVolume();

        });

    </script>

";
        
        $__internal_0fd3beb5143128660cef4706d28b2db037f90457f048d57e72764fbd0cc7acd4->leave($__internal_0fd3beb5143128660cef4706d28b2db037f90457f048d57e72764fbd0cc7acd4_prof);

    }

    public function getTemplateName()
    {
        return "calibracion/2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 20,  70 => 19,  60 => 16,  56 => 15,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/*     <p class="text-center">*/
/* */
/* */
/* */
/* */
/*     <a href="{{ path('calibracion_1') }}" class="btn btn-primary">Anterior</a>*/
/*         <a href="{{ path('calibracion_3') }}" class="btn btn-primary siguiente">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '390',*/
/*                 width: '640',*/
/*                 videoId: 'M7lc1UVf-VE',*/
/*                 events: {*/
/*                     'onReady': onPlayerReady,*/
/*                     'onStateChange': onPlayerStateChange*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume(0);*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/*         function onPlayerStateChange(event) {*/
/*             console.log(event);*/
/*             /*if (event.data == YT.PlayerState.PLAYING && !done) {*/
/*                 setTimeout(stopVideo, 6000);*/
/*                 done = true;*/
/*             }*//* */
/*         }*/
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/*         $btnSiguiente.click(function(e){*/
/*             e.preventDefault();*/
/*             if (player.getVolume() == 0) {*/
/*                 alert("Por favor ajuste el volumen");*/
/*                 return false;*/
/*             }*/
/* */
/*             window.location.href = $(this).attr('href') + "?vol=" + player.getVolume();*/
/* */
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
