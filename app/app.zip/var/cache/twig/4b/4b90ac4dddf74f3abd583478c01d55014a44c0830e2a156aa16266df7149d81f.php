<?php

/* calibracion/1.html.twig */
class __TwigTemplate_bd2abb217227348faad58eff7b01d0bf9f5f26108641af5d470a8ed270ba09e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "calibracion/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d0e34527de561ed2c1ba5441f22709110dae39b89bac37476115a6107107504 = $this->env->getExtension("native_profiler");
        $__internal_2d0e34527de561ed2c1ba5441f22709110dae39b89bac37476115a6107107504->enter($__internal_2d0e34527de561ed2c1ba5441f22709110dae39b89bac37476115a6107107504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calibracion/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2d0e34527de561ed2c1ba5441f22709110dae39b89bac37476115a6107107504->leave($__internal_2d0e34527de561ed2c1ba5441f22709110dae39b89bac37476115a6107107504_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_af3abe6ec90236be5e51b72247cfddd80d23e91ef83dc2aea1c76dadc4bd2b42 = $this->env->getExtension("native_profiler");
        $__internal_af3abe6ec90236be5e51b72247cfddd80d23e91ef83dc2aea1c76dadc4bd2b42->enter($__internal_af3abe6ec90236be5e51b72247cfddd80d23e91ef83dc2aea1c76dadc4bd2b42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p class=\"text-center\">
        <a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\" class=\"btn btn-primary\">Anterior</a>
        <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Siguiente</a>
    </p>
";
        
        $__internal_af3abe6ec90236be5e51b72247cfddd80d23e91ef83dc2aea1c76dadc4bd2b42->leave($__internal_af3abe6ec90236be5e51b72247cfddd80d23e91ef83dc2aea1c76dadc4bd2b42_prof);

    }

    public function getTemplateName()
    {
        return "calibracion/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 6,  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p class="text-center">*/
/*         <a href="{{ path('homepage') }}" class="btn btn-primary">Anterior</a>*/
/*         <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
