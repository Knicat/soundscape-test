<?php

/* videos/2.html.twig */
class __TwigTemplate_8a9a4c30633744c10ce9491d2a45dfeef3474c9cc5d45184ee0a550b6fbef754 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "videos/2.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bd5151fc78050e284d76e80ff655e137890ae8b6a2787dd4e746667e04d3ad47 = $this->env->getExtension("native_profiler");
        $__internal_bd5151fc78050e284d76e80ff655e137890ae8b6a2787dd4e746667e04d3ad47->enter($__internal_bd5151fc78050e284d76e80ff655e137890ae8b6a2787dd4e746667e04d3ad47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "videos/2.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bd5151fc78050e284d76e80ff655e137890ae8b6a2787dd4e746667e04d3ad47->leave($__internal_bd5151fc78050e284d76e80ff655e137890ae8b6a2787dd4e746667e04d3ad47_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_3a5f3609b50acbd3050dd47ed921bc67b37f30784985210289f459653866e975 = $this->env->getExtension("native_profiler");
        $__internal_3a5f3609b50acbd3050dd47ed921bc67b37f30784985210289f459653866e975->enter($__internal_3a5f3609b50acbd3050dd47ed921bc67b37f30784985210289f459653866e975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

";
        
        $__internal_3a5f3609b50acbd3050dd47ed921bc67b37f30784985210289f459653866e975->leave($__internal_3a5f3609b50acbd3050dd47ed921bc67b37f30784985210289f459653866e975_prof);

    }

    // line 11
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_984eb7cab3a3ca252d9e179f2bad69e4cdf63d77f04d149a607b2a137caa4ce5 = $this->env->getExtension("native_profiler");
        $__internal_984eb7cab3a3ca252d9e179f2bad69e4cdf63d77f04d149a607b2a137caa4ce5->enter($__internal_984eb7cab3a3ca252d9e179f2bad69e4cdf63d77f04d149a607b2a137caa4ce5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 12
        echo "    <script>



        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '390',
                width: '640',
                videoId: 'ZLls1Wn6070',
                playerVars: { controls: 0},
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["volumen"]) ? $context["volumen"] : $this->getContext($context, "volumen")), "html", null, true);
        echo ");
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;
        function onPlayerStateChange(event) {
            if(event.data === 0) {
                window.location.href = '";
        // line 44
        echo $this->env->getExtension('routing')->getPath("form_2");
        echo "?";
        echo (isset($context["qs"]) ? $context["qs"] : $this->getContext($context, "qs"));
        echo "';
            }
        }
        function stopVideo() {
            player.stopVideo();
        }

    </script>

";
        
        $__internal_984eb7cab3a3ca252d9e179f2bad69e4cdf63d77f04d149a607b2a137caa4ce5->leave($__internal_984eb7cab3a3ca252d9e179f2bad69e4cdf63d77f04d149a607b2a137caa4ce5_prof);

    }

    public function getTemplateName()
    {
        return "videos/2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 44,  87 => 35,  62 => 12,  56 => 11,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/* */
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '390',*/
/*                 width: '640',*/
/*                 videoId: 'ZLls1Wn6070',*/
/*                 playerVars: { controls: 0},*/
/*                 events: {*/
/*                     'onReady': onPlayerReady,*/
/*                     'onStateChange': onPlayerStateChange*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume({{ volumen }});*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/*         function onPlayerStateChange(event) {*/
/*             if(event.data === 0) {*/
/*                 window.location.href = '{{ path('form_2') }}?{{ qs|raw }}';*/
/*             }*/
/*         }*/
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
