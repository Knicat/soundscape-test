<?php

/* calibracion/3.html.twig */
class __TwigTemplate_d7cf1a37c8d0f9c9a35d7d38207a0251d25a0be65f7cf5a524d871a688422cd0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "calibracion/3.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d37754bb83940ab0ec7b7a5c9758deb0e430927e8e970e971ed7f163d93a4fd = $this->env->getExtension("native_profiler");
        $__internal_0d37754bb83940ab0ec7b7a5c9758deb0e430927e8e970e971ed7f163d93a4fd->enter($__internal_0d37754bb83940ab0ec7b7a5c9758deb0e430927e8e970e971ed7f163d93a4fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calibracion/3.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0d37754bb83940ab0ec7b7a5c9758deb0e430927e8e970e971ed7f163d93a4fd->leave($__internal_0d37754bb83940ab0ec7b7a5c9758deb0e430927e8e970e971ed7f163d93a4fd_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_6d61037f02dcfba13ac59de929be5c3dbb899a9909b50b63d70c5226f01aca02 = $this->env->getExtension("native_profiler");
        $__internal_6d61037f02dcfba13ac59de929be5c3dbb899a9909b50b63d70c5226f01aca02->enter($__internal_6d61037f02dcfba13ac59de929be5c3dbb899a9909b50b63d70c5226f01aca02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto 3</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

    <p class=\"text-center\">




    <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Anterior</a>
        <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("video_1");
        echo "\" class=\"btn btn-primary siguiente\">Siguiente</a>
    </p>
";
        
        $__internal_6d61037f02dcfba13ac59de929be5c3dbb899a9909b50b63d70c5226f01aca02->leave($__internal_6d61037f02dcfba13ac59de929be5c3dbb899a9909b50b63d70c5226f01aca02_prof);

    }

    // line 19
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_38352d33337596dd05bbe4d30e0beb9b6b52a6d4101d269fda6ac1efcc6115f2 = $this->env->getExtension("native_profiler");
        $__internal_38352d33337596dd05bbe4d30e0beb9b6b52a6d4101d269fda6ac1efcc6115f2->enter($__internal_38352d33337596dd05bbe4d30e0beb9b6b52a6d4101d269fda6ac1efcc6115f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 20
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '390',
                width: '640',
                videoId: 'M7lc1UVf-VE',
                events: {
                    'onReady': onPlayerReady
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(0);
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;

        function stopVideo() {
            player.stopVideo();
        }

        \$btnSiguiente.click(function(e){
            e.preventDefault();
            if (player.getVolume() == 0) {
                alert(\"Por favor ajuste el volumen\");
                return false;
            }

            window.location.href = \$(this).attr('href') + \"?vol=\" + player.getVolume();

        });

    </script>

";
        
        $__internal_38352d33337596dd05bbe4d30e0beb9b6b52a6d4101d269fda6ac1efcc6115f2->leave($__internal_38352d33337596dd05bbe4d30e0beb9b6b52a6d4101d269fda6ac1efcc6115f2_prof);

    }

    public function getTemplateName()
    {
        return "calibracion/3.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 20,  70 => 19,  60 => 16,  56 => 15,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto 3</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/*     <p class="text-center">*/
/* */
/* */
/* */
/* */
/*     <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Anterior</a>*/
/*         <a href="{{ path('video_1') }}" class="btn btn-primary siguiente">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '390',*/
/*                 width: '640',*/
/*                 videoId: 'M7lc1UVf-VE',*/
/*                 events: {*/
/*                     'onReady': onPlayerReady*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume(0);*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/* */
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/*         $btnSiguiente.click(function(e){*/
/*             e.preventDefault();*/
/*             if (player.getVolume() == 0) {*/
/*                 alert("Por favor ajuste el volumen");*/
/*                 return false;*/
/*             }*/
/* */
/*             window.location.href = $(this).attr('href') + "?vol=" + player.getVolume();*/
/* */
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
