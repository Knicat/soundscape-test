<?php

/* form/1.html.twig */
class __TwigTemplate_ed5446a696798b223ba3a183d9f2fd90666103d23d5a225c63722baa036d1d35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "form/1.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18a0c3ac40e43e0c99a07d5a03279ebd99aee5c7e91641789e2ab33c369c5b01 = $this->env->getExtension("native_profiler");
        $__internal_18a0c3ac40e43e0c99a07d5a03279ebd99aee5c7e91641789e2ab33c369c5b01->enter($__internal_18a0c3ac40e43e0c99a07d5a03279ebd99aee5c7e91641789e2ab33c369c5b01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/1.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_18a0c3ac40e43e0c99a07d5a03279ebd99aee5c7e91641789e2ab33c369c5b01->leave($__internal_18a0c3ac40e43e0c99a07d5a03279ebd99aee5c7e91641789e2ab33c369c5b01_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_c82e401a275545b3cede7fe35f6313733e218fb78b66bde5777b12efdbf2535e = $this->env->getExtension("native_profiler");
        $__internal_c82e401a275545b3cede7fe35f6313733e218fb78b66bde5777b12efdbf2535e->enter($__internal_c82e401a275545b3cede7fe35f6313733e218fb78b66bde5777b12efdbf2535e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <h1>Formulario 1</h1>
    <hr>
    ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
";
        
        $__internal_c82e401a275545b3cede7fe35f6313733e218fb78b66bde5777b12efdbf2535e->leave($__internal_c82e401a275545b3cede7fe35f6313733e218fb78b66bde5777b12efdbf2535e_prof);

    }

    public function getTemplateName()
    {
        return "form/1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <h1>Formulario 1</h1>*/
/*     <hr>*/
/*     {{ form(form) }}*/
/* {% endblock %}*/
