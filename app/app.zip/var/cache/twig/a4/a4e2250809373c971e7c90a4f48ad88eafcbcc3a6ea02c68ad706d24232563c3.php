<?php

/* layout.html.twig */
class __TwigTemplate_6e7e19939dfb7d54441890087a7e2f85041af65f0f50dbf1fb5d510be4d86a07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fb9378e8c87d729ae4e5e6219765403b2a6b3824be5207addef040bb88ae4aa = $this->env->getExtension("native_profiler");
        $__internal_8fb9378e8c87d729ae4e5e6219765403b2a6b3824be5207addef040bb88ae4aa->enter($__internal_8fb9378e8c87d729ae4e5e6219765403b2a6b3824be5207addef040bb88ae4aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo " - Leandro Beron</title>
        <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />
    </head>
    <body>
        <div class=\"container\">
            <h1>Tesis</h1>
            <hr>
            ";
        // line 12
        $this->displayBlock('content', $context, $blocks);
        // line 13
        echo "        </div>
        <script src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bower_components/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>
        <script>
            // 2. This code loads the IFrame Player API code asynchronously.
            var tag = document.createElement('script');

            tag.src = \"https://www.youtube.com/iframe_api\";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        </script>
        ";
        // line 25
        $this->displayBlock('javascript', $context, $blocks);
        // line 26
        echo "    </body>
</html>
";
        
        $__internal_8fb9378e8c87d729ae4e5e6219765403b2a6b3824be5207addef040bb88ae4aa->leave($__internal_8fb9378e8c87d729ae4e5e6219765403b2a6b3824be5207addef040bb88ae4aa_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_acbdd4d5fdc93c168ac9655132e07bf64efa53700782fcf97cc7ef1bf2d6794c = $this->env->getExtension("native_profiler");
        $__internal_acbdd4d5fdc93c168ac9655132e07bf64efa53700782fcf97cc7ef1bf2d6794c->enter($__internal_acbdd4d5fdc93c168ac9655132e07bf64efa53700782fcf97cc7ef1bf2d6794c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "";
        
        $__internal_acbdd4d5fdc93c168ac9655132e07bf64efa53700782fcf97cc7ef1bf2d6794c->leave($__internal_acbdd4d5fdc93c168ac9655132e07bf64efa53700782fcf97cc7ef1bf2d6794c_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_999102edac3b904d34b1af1b4ce7557553407af7adf98bde1c70dbbe2b263ace = $this->env->getExtension("native_profiler");
        $__internal_999102edac3b904d34b1af1b4ce7557553407af7adf98bde1c70dbbe2b263ace->enter($__internal_999102edac3b904d34b1af1b4ce7557553407af7adf98bde1c70dbbe2b263ace_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_999102edac3b904d34b1af1b4ce7557553407af7adf98bde1c70dbbe2b263ace->leave($__internal_999102edac3b904d34b1af1b4ce7557553407af7adf98bde1c70dbbe2b263ace_prof);

    }

    // line 25
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_0dcff8f71027633e2f82713af67c30ab85464925f8be1e5399e3f6e68ce029cc = $this->env->getExtension("native_profiler");
        $__internal_0dcff8f71027633e2f82713af67c30ab85464925f8be1e5399e3f6e68ce029cc->enter($__internal_0dcff8f71027633e2f82713af67c30ab85464925f8be1e5399e3f6e68ce029cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        
        $__internal_0dcff8f71027633e2f82713af67c30ab85464925f8be1e5399e3f6e68ce029cc->leave($__internal_0dcff8f71027633e2f82713af67c30ab85464925f8be1e5399e3f6e68ce029cc_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 25,  95 => 12,  83 => 4,  74 => 26,  72 => 25,  60 => 16,  56 => 15,  52 => 14,  49 => 13,  47 => 12,  38 => 6,  34 => 5,  30 => 4,  25 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <title>{% block title '' %} - Leandro Beron</title>*/
/*         <link rel="stylesheet" href="{{ asset('bower_components/bootstrap/dist/css/bootstrap.min.css') }}">*/
/*         <link href="{{ asset('css/main.css') }}" rel="stylesheet" type="text/css" />*/
/*     </head>*/
/*     <body>*/
/*         <div class="container">*/
/*             <h1>Tesis</h1>*/
/*             <hr>*/
/*             {% block content %}{% endblock %}*/
/*         </div>*/
/*         <script src="{{ asset('bower_components/jquery/dist/jquery.min.js') }}"></script>*/
/*         <script src="{{ asset('bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>*/
/*         <script src="{{ asset('js/script.js') }}"></script>*/
/*         <script>*/
/*             // 2. This code loads the IFrame Player API code asynchronously.*/
/*             var tag = document.createElement('script');*/
/* */
/*             tag.src = "https://www.youtube.com/iframe_api";*/
/*             var firstScriptTag = document.getElementsByTagName('script')[0];*/
/*             firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);*/
/*         </script>*/
/*         {% block javascript %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
