<?php

/* index.html.twig */
class __TwigTemplate_7fba8620bd4e8beafb332da60200d1eea519a3fba0996bb2340d3a5ac325d93f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_894ffa010f37bbacbd68c163a0450956e0513bf46d8baa2ff80ea50c3dd4bd90 = $this->env->getExtension("native_profiler");
        $__internal_894ffa010f37bbacbd68c163a0450956e0513bf46d8baa2ff80ea50c3dd4bd90->enter($__internal_894ffa010f37bbacbd68c163a0450956e0513bf46d8baa2ff80ea50c3dd4bd90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_894ffa010f37bbacbd68c163a0450956e0513bf46d8baa2ff80ea50c3dd4bd90->leave($__internal_894ffa010f37bbacbd68c163a0450956e0513bf46d8baa2ff80ea50c3dd4bd90_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_65393918bc56a00e9d8fa60883877098715820dd0b8697dd2b5ad9bc0a69feda = $this->env->getExtension("native_profiler");
        $__internal_65393918bc56a00e9d8fa60883877098715820dd0b8697dd2b5ad9bc0a69feda->enter($__internal_65393918bc56a00e9d8fa60883877098715820dd0b8697dd2b5ad9bc0a69feda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <p class=\"text-center\"><a href=\"";
        echo $this->env->getExtension('routing')->getPath("calibracion_1");
        echo "\" class=\"btn btn-primary\">Empezar</a></p>
";
        
        $__internal_65393918bc56a00e9d8fa60883877098715820dd0b8697dd2b5ad9bc0a69feda->leave($__internal_65393918bc56a00e9d8fa60883877098715820dd0b8697dd2b5ad9bc0a69feda_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "layout.html.twig" %}*/
/* */
/* {% block content %}*/
/*     <p class="text-center"><a href="{{ path('calibracion_1') }}" class="btn btn-primary">Empezar</a></p>*/
/* {% endblock %}*/
/* */
