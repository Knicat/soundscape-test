<?php

/* calibracion/3.html.twig */
class __TwigTemplate_48957e2211647f0b9dfc6ca3e4ac48933d80edde097eff2fbfcb5d088bb32174 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "calibracion/3.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_646bd15f0decb584581578e3aa315b9a342f54252a98fc2a3110df4e7063b15a = $this->env->getExtension("native_profiler");
        $__internal_646bd15f0decb584581578e3aa315b9a342f54252a98fc2a3110df4e7063b15a->enter($__internal_646bd15f0decb584581578e3aa315b9a342f54252a98fc2a3110df4e7063b15a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calibracion/3.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_646bd15f0decb584581578e3aa315b9a342f54252a98fc2a3110df4e7063b15a->leave($__internal_646bd15f0decb584581578e3aa315b9a342f54252a98fc2a3110df4e7063b15a_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_d2215b68c198c21bea7ec1c67f1aadd46250605cc2f774d49d99f0e2c1a3c72a = $this->env->getExtension("native_profiler");
        $__internal_d2215b68c198c21bea7ec1c67f1aadd46250605cc2f774d49d99f0e2c1a3c72a->enter($__internal_d2215b68c198c21bea7ec1c67f1aadd46250605cc2f774d49d99f0e2c1a3c72a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto 3</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

    <p class=\"text-center\">




    <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("calibracion_2");
        echo "\" class=\"btn btn-primary\">Anterior</a>
        <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("video", array("index" => 0));
        echo "\" class=\"btn btn-primary siguiente\">Siguiente</a>
    </p>
";
        
        $__internal_d2215b68c198c21bea7ec1c67f1aadd46250605cc2f774d49d99f0e2c1a3c72a->leave($__internal_d2215b68c198c21bea7ec1c67f1aadd46250605cc2f774d49d99f0e2c1a3c72a_prof);

    }

    // line 19
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_12e96a9df61fa59f2e22f9bf911d8dcb15c53e3a7821bd278e11bd1a31be841b = $this->env->getExtension("native_profiler");
        $__internal_12e96a9df61fa59f2e22f9bf911d8dcb15c53e3a7821bd278e11bd1a31be841b->enter($__internal_12e96a9df61fa59f2e22f9bf911d8dcb15c53e3a7821bd278e11bd1a31be841b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 20
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '390',
                width: '640',
                videoId: 'W3Ormr6UpeA',
                events: {
                    'onReady': onPlayerReady
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(0);
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;

        function stopVideo() {
            player.stopVideo();
        }

        \$btnSiguiente.click(function(e){
            e.preventDefault();
            if (player.getVolume() == 0) {
                alert(\"Por favor ajuste el volumen\");
                return false;
            }

            window.location.href = \$(this).attr('href') + \"?vol=\" + player.getVolume();

        });

    </script>

";
        
        $__internal_12e96a9df61fa59f2e22f9bf911d8dcb15c53e3a7821bd278e11bd1a31be841b->leave($__internal_12e96a9df61fa59f2e22f9bf911d8dcb15c53e3a7821bd278e11bd1a31be841b_prof);

    }

    public function getTemplateName()
    {
        return "calibracion/3.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 20,  70 => 19,  60 => 16,  56 => 15,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto 3</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/*     <p class="text-center">*/
/* */
/* */
/* */
/* */
/*     <a href="{{ path('calibracion_2') }}" class="btn btn-primary">Anterior</a>*/
/*         <a href="{{ path('video',{'index':0}) }}" class="btn btn-primary siguiente">Siguiente</a>*/
/*     </p>*/
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '390',*/
/*                 width: '640',*/
/*                 videoId: 'W3Ormr6UpeA',*/
/*                 events: {*/
/*                     'onReady': onPlayerReady*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume(0);*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/* */
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/*         $btnSiguiente.click(function(e){*/
/*             e.preventDefault();*/
/*             if (player.getVolume() == 0) {*/
/*                 alert("Por favor ajuste el volumen");*/
/*                 return false;*/
/*             }*/
/* */
/*             window.location.href = $(this).attr('href') + "?vol=" + player.getVolume();*/
/* */
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
