<?php

/* video.html.twig */
class __TwigTemplate_83b385bb002ce0cb028a241bd87bdd26af61516b9708eb7826c9dfb840ccd29b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "video.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1112ba75170b425a2f8144d1fc7f206e5f1702366b3ff346bad22831553427e = $this->env->getExtension("native_profiler");
        $__internal_d1112ba75170b425a2f8144d1fc7f206e5f1702366b3ff346bad22831553427e->enter($__internal_d1112ba75170b425a2f8144d1fc7f206e5f1702366b3ff346bad22831553427e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "video.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d1112ba75170b425a2f8144d1fc7f206e5f1702366b3ff346bad22831553427e->leave($__internal_d1112ba75170b425a2f8144d1fc7f206e5f1702366b3ff346bad22831553427e_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_0d3fc318a1e2524aa1d5c6a71e475e38125503d76294b4caf416804f24e45007 = $this->env->getExtension("native_profiler");
        $__internal_0d3fc318a1e2524aa1d5c6a71e475e38125503d76294b4caf416804f24e45007->enter($__internal_0d3fc318a1e2524aa1d5c6a71e475e38125503d76294b4caf416804f24e45007_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <p>Calibración</p>
    <p>Texto 3</p>


    ";
        // line 8
        echo "    <div id=\"player\"></div>

";
        
        $__internal_0d3fc318a1e2524aa1d5c6a71e475e38125503d76294b4caf416804f24e45007->leave($__internal_0d3fc318a1e2524aa1d5c6a71e475e38125503d76294b4caf416804f24e45007_prof);

    }

    // line 11
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_f1b7fdf8106b33e43f6072a0b7a723be1a3ccc1557722f60cf4e7b1a658c5cba = $this->env->getExtension("native_profiler");
        $__internal_f1b7fdf8106b33e43f6072a0b7a723be1a3ccc1557722f60cf4e7b1a658c5cba->enter($__internal_f1b7fdf8106b33e43f6072a0b7a723be1a3ccc1557722f60cf4e7b1a658c5cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 12
        echo "    <script>

        var \$btnSiguiente = \$(\".siguiente\");

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '500px',
                width: '100%',
                videoId: '";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "video_id", array()), "html", null, true);
        echo "',
                playerVars: { controls: 0},
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
            event.target.setVolume(";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["volumen"]) ? $context["volumen"] : $this->getContext($context, "volumen")), "html", null, true);
        echo ");
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;

        function onPlayerStateChange(event) {
            if(event.data === 0) {
                window.location.href = '";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("form", array("index" => (isset($context["index"]) ? $context["index"] : $this->getContext($context, "index")))), "html", null, true);
        echo "?";
        echo (isset($context["qs"]) ? $context["qs"] : $this->getContext($context, "qs"));
        echo "';
            }
        }

        function stopVideo() {
            player.stopVideo();
        }



        \$(\".volver-a-empezar\").click(function(e){
            e.preventDefault();
            player.playVideoAt(0);
        });

    </script>

";
        
        $__internal_f1b7fdf8106b33e43f6072a0b7a723be1a3ccc1557722f60cf4e7b1a658c5cba->leave($__internal_f1b7fdf8106b33e43f6072a0b7a723be1a3ccc1557722f60cf4e7b1a658c5cba_prof);

    }

    public function getTemplateName()
    {
        return "video.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 45,  90 => 35,  75 => 23,  62 => 12,  56 => 11,  47 => 8,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'layout.html.twig' %}*/
/* {% block content %}*/
/*     <p>Calibración</p>*/
/*     <p>Texto 3</p>*/
/* */
/* */
/*     {# video #}*/
/*     <div id="player"></div>*/
/* */
/* {% endblock %}*/
/* {% block javascript %}*/
/*     <script>*/
/* */
/*         var $btnSiguiente = $(".siguiente");*/
/* */
/*         // 3. This function creates an <iframe> (and YouTube player)*/
/*         //    after the API code downloads.*/
/*         var player;*/
/*         function onYouTubeIframeAPIReady() {*/
/*             player = new YT.Player('player', {*/
/*                 height: '500px',*/
/*                 width: '100%',*/
/*                 videoId: '{{ video.video_id }}',*/
/*                 playerVars: { controls: 0},*/
/*                 events: {*/
/*                     'onReady': onPlayerReady,*/
/*                     'onStateChange': onPlayerStateChange*/
/*                 }*/
/*             });*/
/*         }*/
/* */
/*         // 4. The API will call this function when the video player is ready.*/
/*         function onPlayerReady(event) {*/
/*             event.target.playVideo();*/
/*             event.target.setVolume({{ volumen }});*/
/*         }*/
/* */
/*         // 5. The API calls this function when the player's state changes.*/
/*         //    The function indicates that when playing a video (state=1),*/
/*         //    the player should play for six seconds and then stop.*/
/*         var done = false;*/
/* */
/*         function onPlayerStateChange(event) {*/
/*             if(event.data === 0) {*/
/*                 window.location.href = '{{ path('form',{'index':index}) }}?{{ qs|raw }}';*/
/*             }*/
/*         }*/
/* */
/*         function stopVideo() {*/
/*             player.stopVideo();*/
/*         }*/
/* */
/* */
/* */
/*         $(".volver-a-empezar").click(function(e){*/
/*             e.preventDefault();*/
/*             player.playVideoAt(0);*/
/*         });*/
/* */
/*     </script>*/
/* */
/* {% endblock %}*/
